
import 'package:flutter/material.dart';

void main() {
  runApp(ToobitDemoApp());
}

class ToobitDemoApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Toobit Grid Demo',
      theme: ThemeData(primarySwatch: Colors.blue),
      home: GridTradingHome(),
    );
  }
}

class GridTradingHome extends StatefulWidget {
  @override
  _GridTradingHomeState createState() => _GridTradingHomeState();
}

class _GridTradingHomeState extends State<GridTradingHome> {
  double leverage = 5;
  double volume = 10;
  List<String> history = [];

  void placeLimitOrder() {
    setState(() {
      history.add("سفارش با حجم $volume و اهرم $leverage ثبت شد.");
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("معامله‌گر گرید - Toobit دمو")),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text("تنظیم اهرم: ${leverage.toStringAsFixed(1)}"),
            Slider(
              min: 1,
              max: 50,
              divisions: 49,
              value: leverage,
              label: leverage.toStringAsFixed(1),
              onChanged: (value) {
                setState(() => leverage = value);
              },
            ),
            Text("تنظیم حجم معامله: ${volume.toStringAsFixed(1)}"),
            Slider(
              min: 1,
              max: 100,
              divisions: 99,
              value: volume,
              label: volume.toStringAsFixed(1),
              onChanged: (value) {
                setState(() => volume = value);
              },
            ),
            ElevatedButton(
              onPressed: placeLimitOrder,
              child: Text("ثبت سفارش لیمیت"),
            ),
            SizedBox(height: 20),
            Text("تاریخچه سفارش‌ها:", style: TextStyle(fontWeight: FontWeight.bold)),
            Expanded(
              child: ListView.builder(
                itemCount: history.length,
                itemBuilder: (context, index) => ListTile(title: Text(history[index])),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
